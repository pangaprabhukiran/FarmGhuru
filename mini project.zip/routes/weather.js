const express = require('express');
const router = express.Router();
const axios = require('axios');

const OWM_KEY = process.env.OWM_API_KEY;
const OWM_BASE = 'https://api.openweathermap.org/data/2.5';

// Map OWM weather icon codes to emojis
function iconEmoji(code) {
  if (!code) return '🌤️';
  const id = parseInt(code);
  if (id >= 200 && id < 300) return '⛈️';
  if (id >= 300 && id < 400) return '🌦️';
  if (id >= 500 && id < 600) return '🌧️';
  if (id >= 600 && id < 700) return '❄️';
  if (id >= 700 && id < 800) return '🌫️';
  if (id === 800) return '☀️';
  if (id === 801) return '🌤️';
  if (id >= 802 && id < 900) return '☁️';
  return '🌤️';
}

function farmingAdvisory(forecasts) {
  const hasRain = forecasts.some(f => f.rain);
  const hasStorm = forecasts.some(f => f.description.toLowerCase().includes('storm') || f.description.toLowerCase().includes('thunder'));
  const maxTemp = Math.max(...forecasts.map(f => f.temp_max));
  const tips = [];

  if (hasStorm) tips.push('⚠️ Thunderstorm expected — move equipment to shelter and avoid open fields.');
  if (hasRain) tips.push('🌧️ Rain expected — avoid pesticide spraying on rainy days to prevent wash-off.');
  if (maxTemp > 38) tips.push('🌡️ High temperatures forecast — irrigate early morning or late evening.');
  if (!hasRain && maxTemp < 35) tips.push('✅ Good conditions for sowing and field operations this week.');
  if (forecasts[0].humidity > 80) tips.push('💧 High humidity — watch for fungal diseases on crops.');

  return tips.length ? tips : ['✅ Normal weather conditions. Continue regular farm activities.'];
}

// GET /api/weather?city=Hyderabad
router.get('/', async (req, res) => {
  const city = req.query.city || 'Hyderabad';
  const lat  = req.query.lat;
  const lon  = req.query.lon;

  // Use mock data if no API key set
  if (!OWM_KEY || OWM_KEY === 'YOUR_OWM_API_KEY') {
    return res.json(getMockWeather(city));
  }

  try {
    let currentUrl, forecastUrl;

    if (lat && lon) {
      currentUrl  = `${OWM_BASE}/weather?lat=${lat}&lon=${lon}&appid=${OWM_KEY}&units=metric`;
      forecastUrl = `${OWM_BASE}/forecast?lat=${lat}&lon=${lon}&appid=${OWM_KEY}&units=metric`;
    } else {
      currentUrl  = `${OWM_BASE}/weather?q=${encodeURIComponent(city)}&appid=${OWM_KEY}&units=metric`;
      forecastUrl = `${OWM_BASE}/forecast?q=${encodeURIComponent(city)}&appid=${OWM_KEY}&units=metric`;
    }

    const [currentRes, forecastRes] = await Promise.all([
      axios.get(currentUrl),
      axios.get(forecastUrl)
    ]);

    const cur = currentRes.data;
    const fList = forecastRes.data.list;

    // Aggregate daily forecasts (OWM free tier gives 3-hourly for 5 days)
    const dailyMap = {};
    fList.forEach(item => {
      const date = item.dt_txt.split(' ')[0];
      if (!dailyMap[date]) {
        dailyMap[date] = {
          date,
          temps: [],
          descriptions: [],
          icons: [],
          rain: false,
          humidity: []
        };
      }
      dailyMap[date].temps.push(item.main.temp);
      dailyMap[date].descriptions.push(item.weather[0].description);
      dailyMap[date].icons.push(item.weather[0].id);
      dailyMap[date].humidity.push(item.main.humidity);
      if (item.rain && item.rain['3h'] > 0) dailyMap[date].rain = true;
    });

    const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    const forecasts = Object.values(dailyMap).slice(0, 7).map((d, i) => {
      const avgTemp = Math.round(d.temps.reduce((a, b) => a + b, 0) / d.temps.length);
      const maxTemp = Math.round(Math.max(...d.temps));
      const minTemp = Math.round(Math.min(...d.temps));
      const desc = d.descriptions[Math.floor(d.descriptions.length / 2)];
      const iconId = d.icons[Math.floor(d.icons.length / 2)];
      const avgHumidity = Math.round(d.humidity.reduce((a, b) => a + b, 0) / d.humidity.length);
      const dateObj = new Date(d.date);
      return {
        date: d.date,
        day: i === 0 ? 'Today' : days[dateObj.getDay()],
        temp: avgTemp,
        temp_max: maxTemp,
        temp_min: minTemp,
        description: desc,
        emoji: iconEmoji(iconId),
        rain: d.rain,
        humidity: avgHumidity
      };
    });

    const advisory = farmingAdvisory(forecasts);

    res.json({
      success: true,
      city: cur.name,
      country: cur.sys.country,
      current: {
        temp: Math.round(cur.main.temp),
        feels_like: Math.round(cur.main.feels_like),
        humidity: cur.main.humidity,
        wind_speed: cur.wind.speed,
        description: cur.weather[0].description,
        emoji: iconEmoji(cur.weather[0].id)
      },
      forecasts,
      advisory
    });
  } catch (err) {
    console.error('Weather API error:', err.message);
    // Fallback to mock
    res.json(getMockWeather(city));
  }
});

function getMockWeather(city) {
  const days = ['Today','Mon','Tue','Wed','Thu','Fri','Sun'];
  const mock = [
    { emoji:'☀️', desc:'Clear sky',       rain:false, t:34, hi:36, lo:26, hum:45 },
    { emoji:'⛅', desc:'Partly cloudy',   rain:false, t:31, hi:33, lo:24, hum:55 },
    { emoji:'🌧️', desc:'Moderate rain',   rain:true,  t:27, hi:29, lo:22, hum:80 },
    { emoji:'⛈️', desc:'Thunderstorm',    rain:true,  t:25, hi:27, lo:21, hum:88 },
    { emoji:'🌦️', desc:'Light showers',   rain:true,  t:28, hi:30, lo:23, hum:75 },
    { emoji:'☀️', desc:'Sunny',           rain:false, t:33, hi:35, lo:25, hum:42 },
    { emoji:'⛅', desc:'Cloudy',          rain:false, t:32, hi:34, lo:25, hum:50 }
  ];
  return {
    success: true,
    city,
    country: 'IN',
    mock: true,
    current: { temp:34, feels_like:37, humidity:45, wind_speed:3.2, description:'Clear sky', emoji:'☀️' },
    forecasts: mock.map((m, i) => ({
      day: days[i], temp: m.t, temp_max: m.hi, temp_min: m.lo,
      description: m.desc, emoji: m.emoji, rain: m.rain, humidity: m.hum
    })),
    advisory: [
      '🌧️ Rain expected mid-week — avoid pesticide spraying Wednesday–Thursday.',
      '✅ Monday is ideal for sowing and field operations.',
      '💧 High humidity on rainy days — watch for fungal diseases.'
    ]
  };
}

module.exports = router;