const express = require('express');
const router  = express.Router();

// Comprehensive crop database with soil, season, rainfall, temperature compatibility
const CROP_DB = [
  { name:'Paddy (Rice)',  soil:['Alluvial','Clay'],         season:['Kharif'],           min_rain:1000, max_temp:38, min_temp:20, yield:'20–35 q/acre',  profit:'Medium',  days:120, water:'High',   market_demand:'Very High' },
  { name:'Wheat',         soil:['Alluvial','Loamy','Black'],season:['Rabi'],             min_rain:300,  max_temp:28, min_temp:10, yield:'15–22 q/acre',  profit:'High',    days:120, water:'Medium', market_demand:'High' },
  { name:'Cotton',        soil:['Black','Alluvial'],        season:['Kharif'],           min_rain:600,  max_temp:40, min_temp:20, yield:'8–12 q/acre',   profit:'High',    days:160, water:'Medium', market_demand:'High' },
  { name:'Soybean',       soil:['Loamy','Black','Red'],     season:['Kharif'],           min_rain:600,  max_temp:35, min_temp:18, yield:'8–12 q/acre',   profit:'Medium',  days:100, water:'Medium', market_demand:'Medium' },
  { name:'Groundnut',     soil:['Sandy Loam','Red','Loamy'],season:['Kharif','Zaid'],    min_rain:400,  max_temp:38, min_temp:22, yield:'6–10 q/acre',   profit:'High',    days:100, water:'Low',    market_demand:'High' },
  { name:'Maize',         soil:['Loamy','Alluvial','Red'],  season:['Kharif','Rabi'],    min_rain:500,  max_temp:35, min_temp:15, yield:'15–20 q/acre',  profit:'Medium',  days:90,  water:'Medium', market_demand:'Medium' },
  { name:'Jowar',         soil:['Black','Loamy','Red'],     season:['Kharif','Rabi'],    min_rain:300,  max_temp:40, min_temp:18, yield:'10–14 q/acre',  profit:'Low',     days:100, water:'Low',    market_demand:'Low' },
  { name:'Bajra',         soil:['Sandy Loam','Red','Loamy'],season:['Kharif'],           min_rain:250,  max_temp:42, min_temp:20, yield:'8–12 q/acre',   profit:'Low',     days:85,  water:'Low',    market_demand:'Medium' },
  { name:'Chickpea',      soil:['Black','Loamy','Alluvial'],season:['Rabi'],             min_rain:300,  max_temp:26, min_temp:8,  yield:'5–8 q/acre',    profit:'Medium',  days:100, water:'Low',    market_demand:'High' },
  { name:'Pigeon Pea',    soil:['Loamy','Red','Black'],     season:['Kharif'],           min_rain:500,  max_temp:38, min_temp:18, yield:'5–8 q/acre',    profit:'High',    days:150, water:'Low',    market_demand:'High' },
  { name:'Sunflower',     soil:['Loamy','Red','Black'],     season:['Rabi','Zaid'],      min_rain:400,  max_temp:35, min_temp:15, yield:'6–9 q/acre',    profit:'Medium',  days:90,  water:'Medium', market_demand:'Medium' },
  { name:'Turmeric',      soil:['Loamy','Sandy Loam','Red'],season:['Kharif'],           min_rain:700,  max_temp:35, min_temp:20, yield:'25–35 q/acre',  profit:'Very High',days:250, water:'High',  market_demand:'High' },
  { name:'Red Chilli',    soil:['Loamy','Alluvial','Black'],season:['Kharif','Rabi'],    min_rain:500,  max_temp:35, min_temp:18, yield:'4–8 q/acre',    profit:'High',    days:150, water:'Medium', market_demand:'Very High' },
  { name:'Tomato',        soil:['Loamy','Alluvial'],        season:['Rabi','Zaid'],      min_rain:400,  max_temp:32, min_temp:15, yield:'80–120 q/acre', profit:'High',    days:90,  water:'Medium', market_demand:'High' },
  { name:'Onion',         soil:['Loamy','Alluvial','Sandy'],season:['Rabi'],             min_rain:300,  max_temp:28, min_temp:12, yield:'60–80 q/acre',  profit:'High',    days:120, water:'Medium', market_demand:'Very High' },
  { name:'Brinjal',       soil:['Loamy','Sandy Loam'],      season:['Rabi','Zaid'],      min_rain:350,  max_temp:35, min_temp:15, yield:'60–80 q/acre',  profit:'Medium',  days:80,  water:'Medium', market_demand:'Medium' },
  { name:'Sugarcane',     soil:['Alluvial','Loamy','Black'],season:['Kharif'],           min_rain:800,  max_temp:38, min_temp:18, yield:'250–350 q/acre',profit:'Very High',days:365, water:'Very High',market_demand:'High' },
  { name:'Banana',        soil:['Loamy','Alluvial'],        season:['Kharif','Rabi'],    min_rain:700,  max_temp:38, min_temp:18, yield:'150–200 q/acre',profit:'Very High',days:365, water:'High',   market_demand:'High' },
  { name:'Mango',         soil:['Loamy','Alluvial','Sandy'],season:['Zaid'],             min_rain:500,  max_temp:40, min_temp:15, yield:'40–80 q/acre',  profit:'Very High',days:365, water:'Low',    market_demand:'Very High' },
  { name:'Cashew',        soil:['Laterite','Red','Sandy'],  season:['Kharif'],           min_rain:700,  max_temp:38, min_temp:15, yield:'6–10 q/acre',   profit:'High',    days:365, water:'Low',    market_demand:'High' },
  { name:'Sesame',        soil:['Red','Sandy Loam','Loamy'],season:['Kharif','Zaid'],    min_rain:300,  max_temp:40, min_temp:22, yield:'2–4 q/acre',    profit:'Medium',  days:80,  water:'Low',    market_demand:'Medium' },
  { name:'Horse Gram',    soil:['Red','Laterite','Sandy'],  season:['Rabi'],             min_rain:200,  max_temp:35, min_temp:12, yield:'4–6 q/acre',    profit:'Low',     days:90,  water:'Low',    market_demand:'Low' },
  { name:'Cowpea',        soil:['Sandy Loam','Loamy','Red'],season:['Zaid','Kharif'],    min_rain:400,  max_temp:38, min_temp:20, yield:'5–8 q/acre',    profit:'Medium',  days:60,  water:'Low',    market_demand:'Medium' },
  { name:'Watermelon',    soil:['Sandy Loam','Sandy'],      season:['Zaid'],             min_rain:300,  max_temp:38, min_temp:20, yield:'80–120 q/acre', profit:'High',    days:75,  water:'Medium', market_demand:'High' },
  { name:'Cucumber',      soil:['Sandy Loam','Loamy'],      season:['Zaid','Rabi'],      min_rain:350,  max_temp:35, min_temp:18, yield:'50–80 q/acre',  profit:'Medium',  days:60,  water:'Medium', market_demand:'Medium' },
  { name:'Coconut',       soil:['Sandy Loam','Laterite','Alluvial'],season:['All'],     min_rain:700,  max_temp:38, min_temp:18, yield:'3000 nuts/acre', profit:'High',   days:365, water:'Medium', market_demand:'High' },
];

const SEASON_MAP = { 'kharif':'Kharif', 'rabi':'Rabi', 'zaid':'Zaid', 'all':'All' };
const SOIL_NORMALIZE = {
  'black':'Black', 'black soil':'Black', 'regur':'Black',
  'alluvial':'Alluvial', 'alluvial soil':'Alluvial',
  'red':'Red', 'red soil':'Red', 'red and yellow':'Red',
  'loamy':'Loamy', 'loam':'Loamy',
  'sandy':'Sandy', 'sandy loam':'Sandy Loam',
  'laterite':'Laterite', 'lateritic':'Laterite',
  'clay':'Clay'
};

// POST /api/crop/suggest
router.post('/suggest', (req, res) => {
  try {
    const {
      soil_type,
      season,
      rainfall_mm,
      temperature,
      water_availability,
      farm_size
    } = req.body;

    const soilKey    = (soil_type || '').toLowerCase().trim();
    const seasonKey  = (season || '').toLowerCase().trim();
    const rain       = parseFloat(rainfall_mm) || 600;
    const temp       = parseFloat(temperature) || 28;
    const normSoil   = SOIL_NORMALIZE[soilKey] || 'Loamy';
    const normSeason = SEASON_MAP[seasonKey] || 'Kharif';

    // Filter and score crops
    const scored = CROP_DB
      .map(crop => {
        let score = 0;
        const reasons = [];

        // Soil match (highest weight)
        if (crop.soil.some(s => s.toLowerCase() === normSoil.toLowerCase())) {
          score += 40;
          reasons.push(`Ideal soil match (${normSoil})`);
        } else {
          score += 10; // partial credit
        }

        // Season match
        if (crop.season.includes(normSeason) || crop.season.includes('All')) {
          score += 35;
          reasons.push(`Best for ${normSeason} season`);
        }

        // Rainfall compatibility
        if (rain >= crop.min_rain) {
          score += 15;
          reasons.push(`Sufficient rainfall (${rain}mm)`);
        } else if (rain >= crop.min_rain * 0.7) {
          score += 7;
          reasons.push('Needs supplemental irrigation');
        }

        // Temperature compatibility
        if (temp <= crop.max_temp && temp >= crop.min_temp) {
          score += 10;
          reasons.push('Temperature range suitable');
        }

        // Bonus for high market demand
        if (crop.market_demand === 'Very High') score += 5;
        if (crop.market_demand === 'High') score += 3;

        return { ...crop, score, reasons };
      })
      .filter(c => c.score >= 40)
      .sort((a, b) => b.score - a.score)
      .slice(0, 8);

    if (scored.length === 0) {
      return res.json({
        success: true,
        message: 'No exact matches found. Showing best available options.',
        recommendations: CROP_DB.slice(0, 5).map(c => ({ ...c, score: 30, reasons: ['General recommendation'] }))
      });
    }

    res.json({
      success: true,
      input: { soil: normSoil, season: normSeason, rainfall_mm: rain, temperature: temp },
      total_matches: scored.length,
      recommendations: scored
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/crop/soils — list of soils
router.get('/soils', (req, res) => {
  res.json({ soils: Object.values(SOIL_NORMALIZE).filter((v,i,a) => a.indexOf(v)===i) });
});

module.exports = router;