const express = require('express');
const router  = express.Router();
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const axios   = require('axios');

const GEMINI_KEY         = process.env.GEMINI_API_KEY;
const GEMINI_MODEL       = process.env.GEMINI_MODEL || 'gemini-1.5-flash';
const GEMINI_API_VERSION = process.env.GEMINI_API_VERSION || 'v1';
const GEMINI_METHOD      = process.env.GEMINI_METHOD || 'generate';
const GEMINI_ENDPOINT    = `https://generativelanguage.googleapis.com/${GEMINI_API_VERSION}`;
const GEMINI_URL         = `${GEMINI_ENDPOINT}/models/${GEMINI_MODEL}:${GEMINI_METHOD}`;

// ── Multer: file upload with strict validation ───────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '..', 'uploads');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const unique = `crop_${Date.now()}_${Math.round(Math.random() * 1e6)}`;
    cb(null, unique + path.extname(file.originalname).toLowerCase());
  }
});

// ── Middleware: ONLY jpg, jpeg, png allowed ───────────────────────
const fileFilter = (req, file, cb) => {
  const allowed = ['image/jpeg', 'image/jpg', 'image/png'];
  const ext = path.extname(file.originalname).toLowerCase();
  const allowedExt = ['.jpg', '.jpeg', '.png'];

  if (allowed.includes(file.mimetype) && allowedExt.includes(ext)) {
    cb(null, true);  // Accept file
  } else {
    cb(new Error(`Invalid file type "${file.originalname}". Only JPG, JPEG, and PNG images are accepted.`), false);
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10 MB max
    files: 1
  }
});

// ── Gemini prompt ─────────────────────────────────────────────────
const SYSTEM_PROMPT = `You are an expert agricultural plant pathologist AI with deep knowledge of Indian farming conditions, crop diseases, and organic/chemical treatment options. Analyze the provided plant/crop image carefully.

Respond ONLY in valid JSON (no markdown, no code fences) with this exact structure:
{
  "is_plant": true,
  "plant_type": "Name of the crop/plant (e.g., Rice, Tomato, Wheat, Cotton)",
  "health_status": "Healthy | Diseased | Pest-Damaged | Nutritional Deficiency | Unknown",
  "disease_name": "Specific disease name or 'None' if healthy",
  "risk_level": "None | Low | Medium | High | Critical",
  "risk_score": 0-100,
  "symptoms_observed": ["list", "of", "visible", "symptoms"],
  "causes": ["list", "of", "likely", "causes"],
  "affected_parts": ["leaf", "stem", "root", etc],
  "spread_risk": "Low | Medium | High — brief explanation",
  "organic_treatments": [
    {"step": 1, "action": "treatment step", "product": "product name or ingredient", "frequency": "how often"}
  ],
  "chemical_treatments": [
    {"step": 1, "action": "treatment step", "product": "chemical product name", "dosage": "dose", "frequency": "how often"}
  ],
  "preventive_tips": ["tip 1", "tip 2", "tip 3"],
  "urgent_action": "One clear sentence about the most urgent thing the farmer should do right now",
  "recovery_timeline": "Expected recovery time with proper treatment",
  "yield_impact": "Estimated yield loss if untreated (e.g., 30–60% loss)",
  "confidence": 0-100
}

Rules:
- If the image is NOT a plant/crop, set is_plant to false and fill only is_plant and a "message" field.
- Be specific to Indian farming context — mention locally available products.
- risk_score: 0=None, 1-25=Low, 26-50=Medium, 51-75=High, 76-100=Critical
- Always provide at least 3 organic and 2 chemical treatment steps.
- Preventive tips should be practical for small Indian farmers.
- Do NOT wrap in markdown. Output raw JSON only.`;

// POST /api/disease/analyze
router.post('/analyze', (req, res) => {
  // Handle multer errors in a clean way
  upload.single('cropImage')(req, res, async (err) => {
    if (err) {
      if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
          return res.status(400).json({ success: false, error: 'File too large. Maximum size is 10 MB.' });
        }
        return res.status(400).json({ success: false, error: `Upload error: ${err.message}` });
      }
      // fileFilter rejection
      return res.status(400).json({ success: false, error: err.message });
    }

    if (!req.file) {
      return res.status(400).json({ success: false, error: 'No image uploaded. Please select a JPG or PNG file.' });
    }

    const filePath = req.file.path;

    try {
      // Read file as base64
      const imageBuffer = fs.readFileSync(filePath);
      const base64Image = imageBuffer.toString('base64');
      const mimeType    = req.file.mimetype;

      // If no Gemini key, return mock result
      if (!GEMINI_KEY || GEMINI_KEY === 'YOUR_GEMINI_API_KEY') {
        fs.unlinkSync(filePath);
        return res.json(getMockDiseaseResult());
      }

      // Call Gemini Vision API
      const response = await axios.post(
        `${GEMINI_URL}?key=${GEMINI_KEY}`,
        {
          contents: [{
            parts: [
              { text: SYSTEM_PROMPT },
              { inline_data: { mime_type: mimeType, data: base64Image } }
            ]
          }],
          generationConfig: {
            temperature: 0.2,
            maxOutputTokens: 2048,
            responseMimeType: 'application/json'
          }
        },
        { headers: { 'Content-Type': 'application/json' }, timeout: 30000 }
      );

      // Parse Gemini response
      let text = response.data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
      // Strip any accidental code fences
      text = text.replace(/```json|```/g, '').trim();

      let analysis;
      try {
        analysis = JSON.parse(text);
      } catch (parseErr) {
        console.error('Gemini JSON parse error:', parseErr.message, '\nRaw:', text);
        analysis = { parse_error: true, raw: text };
      }

      // Clean up uploaded file after analysis
      fs.unlinkSync(filePath);

      return res.json({
        success: true,
        filename: req.file.originalname,
        analysis
      });

    } catch (apiErr) {
      // Clean up file on error
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      console.error('Gemini API error:', apiErr.response?.data || apiErr.message);

      const apiDetail = apiErr.response?.data || apiErr.message;
      // Detect model-not-found / unsupported method errors and provide guidance
      const statusCode = apiErr.response?.status;
      const errStatus = apiErr.response?.data?.error?.status || apiErr.response?.data?.error?.code;

      let userMessage = 'AI analysis failed. Please try again.';
      if (statusCode === 404 || errStatus === 'NOT_FOUND') {
        userMessage = `Model "${GEMINI_MODEL}" is not found for this API version, or it does not support the configured Gemini method. Set GEMINI_API_VERSION=v1 and GEMINI_METHOD=generate, or choose a supported GEMINI_MODEL for your account.`;
      }

      return res.status(500).json({
        success: false,
        error: userMessage,
        detail: apiDetail
      });
    }
  });
});

// Mock response for development without API key
function getMockDiseaseResult() {
  return {
    success: true,
    mock: true,
    filename: 'sample_crop.jpg',
    analysis: {
      is_plant: true,
      plant_type: 'Tomato',
      health_status: 'Diseased',
      disease_name: 'Early Blight (Alternaria solani)',
      risk_level: 'High',
      risk_score: 68,
      symptoms_observed: [
        'Dark brown concentric ring spots on leaves',
        'Yellow halo around lesions',
        'Lower leaves affected first',
        'Stem lesions near soil level'
      ],
      causes: [
        'Fungal pathogen Alternaria solani',
        'Warm humid weather (24–29°C)',
        'Overhead irrigation splash',
        'Poor air circulation between plants'
      ],
      affected_parts: ['leaves', 'stem', 'fruit (if advanced)'],
      spread_risk: 'High — spreads rapidly in humid conditions via spores',
      organic_treatments: [
        { step:1, action:'Remove and destroy all infected leaves immediately', product:'Manual removal + burning', frequency:'Daily until controlled' },
        { step:2, action:'Spray Bordeaux mixture (copper sulfate + lime)', product:'Bordeaux mixture 1%', frequency:'Every 7 days' },
        { step:3, action:'Apply neem oil spray at dusk', product:'Neem oil 5ml/litre water', frequency:'Every 5 days' },
        { step:4, action:'Mulch around plants to prevent soil splash', product:'Straw or dry leaves', frequency:'Once' }
      ],
      chemical_treatments: [
        { step:1, action:'Spray systemic fungicide', product:'Mancozeb 75% WP', dosage:'2.5g per litre water', frequency:'Every 7–10 days' },
        { step:2, action:'Alternate with contact fungicide', product:'Chlorothalonil 75% WP', dosage:'2g per litre water', frequency:'Every 10 days' }
      ],
      preventive_tips: [
        'Rotate crops — avoid planting tomato/potato in same spot for 3 years',
        'Maintain 45–60 cm spacing between plants for airflow',
        'Use drip irrigation instead of overhead watering',
        'Plant resistant varieties like Arka Vikas or Pusa Ruby',
        'Apply potassium-rich fertilizer to strengthen plant immunity'
      ],
      urgent_action: 'Remove all infected lower leaves today and apply Bordeaux mixture or Mancozeb spray within 24 hours to prevent further spread.',
      recovery_timeline: '3–4 weeks with consistent treatment; stop new infections within 1 week',
      yield_impact: '40–70% yield loss if left untreated for more than 2 weeks',
      confidence: 87
    }
  };
}

module.exports = router;