const apiBase = '/api';
let marketData = [];
let marketFilterValue = 'all';
let marketSearchQuery = '';

// Global scroll function - available immediately, before DOMContentLoaded
function scrollTo(sectionId) {
  const el = document.getElementById(sectionId);
  if (!el) {
    console.warn(`Section not found: ${sectionId}`);
    return;
  }
  el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Global language switching - available immediately
function toggleLangMenu() {
  const menu = document.getElementById('lang-menu');
  if (menu) menu.classList.toggle('open');
}

function setLang(lang) {
  if (!window.T?.[lang]) {
    console.warn(`Language not available: ${lang}`);
    return;
  }
  window.LANG = lang;
  localStorage.setItem('farmghuru_lang', lang);
  setLanguageText();
  closeLangMenu();
  showToast(window.T[lang].toast_lang || 'Language changed');
}

function closeLangMenu() {
  const menu = document.getElementById('lang-menu');
  if (menu) menu.classList.remove('open');
}

window.addEventListener('DOMContentLoaded', () => {
  const savedLang = localStorage.getItem('farmghuru_lang');
  if (savedLang && window.T?.[savedLang]) {
    window.LANG = savedLang;
  }

  setLanguageText();
  document.addEventListener('click', event => {
    if (!event.target.closest('.lang-selector')) closeLangMenu();
  });

  loadMarket();
});

function setLanguageText() {
  document.querySelectorAll('[data-k]').forEach(el => {
    const key = el.dataset.k;
    const translation = window.T?.[window.LANG]?.[key];
    if (translation != null) {
      el.textContent = translation;
    }
  });

  document.querySelectorAll('[data-k-placeholder]').forEach(el => {
    const key = el.dataset.kPlaceholder;
    const translation = window.T?.[window.LANG]?.[key];
    if (translation != null) {
      el.placeholder = translation;
    }
  });

  const currentLang = document.getElementById('cur-lang');
  if (currentLang) currentLang.textContent = window.LANG.toUpperCase();

  document.querySelectorAll('.lang-opt').forEach(opt => {
    opt.classList.toggle('active', opt.dataset.lang === window.LANG);
  });
  document.querySelectorAll('.lang-card').forEach(card => {
    card.classList.toggle('active', card.dataset.lang === window.LANG);
  });
}

function showToast(message) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(window.toastTimeout);
  window.toastTimeout = setTimeout(() => toast.classList.remove('show'), 3200);
}

function startButtonLoading(button) {
  if (!button) return;
  button.disabled = true;
  const spinner = button.querySelector('.btn-spinner');
  if (spinner) spinner.classList.remove('hidden');
}

function stopButtonLoading(button) {
  if (!button) return;
  button.disabled = false;
  const spinner = button.querySelector('.btn-spinner');
  if (spinner) spinner.classList.add('hidden');
}

function renderError(targetId, message) {
  const target = document.getElementById(targetId);
  if (!target) return;
  target.innerHTML = `<div class="error-box">${message}</div>`;
}

async function getCropSuggestions() {
  const button = document.getElementById('crop-btn');
  const soilType = document.getElementById('soilType')?.value;
  const season = document.getElementById('cropSeason')?.value;
  const rainfall = document.getElementById('rainfall')?.value;
  const temperature = document.getElementById('temperature')?.value;
  const waterAvail = document.getElementById('waterAvail')?.value;

  if (!soilType || !season || !rainfall || !temperature || !waterAvail) {
    showToast('Please complete all crop advisor fields.');
    return;
  }

  startButtonLoading(button);
  document.getElementById('crop-results').innerHTML = '<div class="loading-spinner">Fetching crop recommendations...</div>';

  try {
    const response = await fetch(`${apiBase}/crop/suggest`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        soil_type: soilType,
        season,
        rainfall_mm: rainfall,
        temperature,
        water_availability: waterAvail
      })
    });
    const data = await response.json();

    if (!data.success) {
      renderError('crop-results', data.error || 'Unable to fetch recommendations.');
      return;
    }

    renderCropResults(data);
  } catch (err) {
    renderError('crop-results', 'Crop recommendation service is unavailable. Please try again later.');
  } finally {
    stopButtonLoading(button);
  }
}

function renderCropResults(data) {
  const container = document.getElementById('crop-results');
  container.innerHTML = '';

  if (!data.recommendations || !data.recommendations.length) {
    container.innerHTML = `<div class="results-placeholder"><div class="placeholder-icon">🌾</div><div class="placeholder-text">${data.message || 'No crop recommendations found at this time.'}</div></div>`;
    return;
  }

  const grid = document.createElement('div');
  grid.className = 'crop-grid';

  data.recommendations.forEach(crop => {
    const card = document.createElement('article');
    card.className = 'crop-card';
    card.innerHTML = `
      <div class="crop-card-top">
        <div class="crop-name">${crop.name}</div>
        <span class="crop-score-badge">${crop.score}%</span>
      </div>
      <div class="crop-meta">
        <span class="meta-chip">Season: ${Array.isArray(crop.season) ? crop.season.join(', ') : crop.season}</span>
        <span class="meta-chip">Soil: ${Array.isArray(crop.soil) ? crop.soil.join(', ') : crop.soil}</span>
        <span class="meta-chip">Demand: ${crop.market_demand}</span>
      </div>
      <div class="crop-reasons">
        ${crop.reasons.slice(0, 3).map(reason => `<span>• ${reason}</span>`).join('')}
      </div>
      <div class="crop-stats-row">
        <div class="cstat"><div class="cstat-val">${crop.yield}</div><div class="cstat-lbl">Yield</div></div>
        <div class="cstat"><div class="cstat-val">${crop.profit}</div><div class="cstat-lbl">Profit</div></div>
        <div class="cstat"><div class="cstat-val">${crop.water}</div><div class="cstat-lbl">Water</div></div>
      </div>
    `;
    grid.appendChild(card);
  });

  container.appendChild(grid);

  if (data.message) {
    const note = document.createElement('div');
    note.className = 'mock-note';
    note.textContent = data.message;
    container.appendChild(note);
  }
}

async function getWeather() {
  const city = document.getElementById('cityInput')?.value.trim();
  if (!city) {
    showToast('Please enter a city name to fetch weather.');
    return;
  }
  await fetchWeather({ city });
}

function getWeatherByLocation() {
  if (!navigator.geolocation) {
    showToast('Geolocation is not supported by your browser.');
    return;
  }

  document.getElementById('weather-results').innerHTML = '<div class="loading-spinner">Getting location…</div>';
  navigator.geolocation.getCurrentPosition(
    position => {
      fetchWeather({ lat: position.coords.latitude, lon: position.coords.longitude });
    },
    () => {
      renderError('weather-results', 'Unable to get your location. Please allow access or enter your city manually.');
    },
    { timeout: 15000 }
  );
}

async function fetchWeather(params) {
  const target = document.getElementById('weather-results');
  target.innerHTML = '<div class="loading-spinner">Loading weather forecast...</div>';

  const query = new URLSearchParams(params).toString();
  try {
    const response = await fetch(`${apiBase}/weather?${query}`);
    const data = await response.json();
    if (!data.success) {
      renderError('weather-results', 'Unable to load weather. Please try again.');
      return;
    }
    renderWeatherResults(data);
  } catch (err) {
    renderError('weather-results', 'Weather service unavailable. Please try again later.');
  }
}

function renderWeatherResults(data) {
  const target = document.getElementById('weather-results');
  target.innerHTML = '';

  const current = document.createElement('section');
  current.className = 'current-weather';
  current.innerHTML = `
    <div class="cw-row">
      <div>
        <div class="cw-city">${data.city}, ${data.country}</div>
        <div class="cw-temp">${data.current.temp}°C</div>
        <div class="cw-desc">${data.current.description}</div>
      </div>
      <div class="cw-emoji">${data.current.emoji}</div>
    </div>
    <div class="cw-stats">
      <div class="cw-stat"><div class="cw-stat-val">Feels ${data.current.feels_like}°C</div><div class="cw-stat-lbl">Feels like</div></div>
      <div class="cw-stat"><div class="cw-stat-val">${data.current.humidity}%</div><div class="cw-stat-lbl">Humidity</div></div>
      <div class="cw-stat"><div class="cw-stat-val">${data.current.wind_speed} m/s</div><div class="cw-stat-lbl">Wind speed</div></div>
    </div>
  `;

  const forecast = document.createElement('div');
  forecast.className = 'forecast-row';
  (data.forecasts || []).slice(0, 7).forEach(day => {
    forecast.innerHTML += `
      <div class="forecast-day">
        <div class="fd-day">${day.day}</div>
        <div class="fd-icon">${day.emoji}</div>
        <div class="fd-temp">${day.temp}°C</div>
        <div class="fd-range">${day.temp_min}° / ${day.temp_max}°</div>
        <div class="fd-rain">${day.rain ? 'Rain possible' : 'Dry'}</div>
      </div>
    `;
  });

  const advisory = document.createElement('div');
  advisory.className = 'advisory-box';
  advisory.innerHTML = `
    <div class="advisory-title">Weather Advisory</div>
    <ul class="advisory-list">
      ${(data.advisory || []).map(item => `<li>${item}</li>`).join('')}
    </ul>
  `;

  target.appendChild(current);
  target.appendChild(forecast);
  target.appendChild(advisory);
}

async function loadMarket() {
  const results = document.getElementById('market-results');
  const summary = document.getElementById('market-summary');
  summary.classList.add('hidden');
  results.innerHTML = '<div class="loading-spinner">Loading mandi prices...</div>';

  try {
    const response = await fetch(`${apiBase}/market`);
    const data = await response.json();
    if (!data.success) {
      renderError('market-results', 'Unable to load market prices.');
      return;
    }
    marketData = data.data || [];
    marketFilterValue = document.getElementById('marketFilter')?.value || 'all';
    marketSearchQuery = document.getElementById('marketSearch')?.value.trim().toLowerCase() || '';
    renderMarketSummary(data.summary);
    applyMarketFilter();
  } catch (err) {
    renderError('market-results', 'Market service unavailable. Please try again later.');
  }
}

function renderMarketSummary(summary) {
  const summaryEl = document.getElementById('market-summary');
  summaryEl.innerHTML = `
    <div class="ms-card"><div class="ms-val">${summary.total}</div><div class="ms-lbl">Total Listings</div></div>
    <div class="ms-card"><div class="ms-val">${summary.trending_up}</div><div class="ms-lbl">Price Rising</div></div>
    <div class="ms-card"><div class="ms-val">${summary.trending_down}</div><div class="ms-lbl">Price Falling</div></div>
    <div class="ms-card"><div class="ms-val">${summary.avg_change_pct}%</div><div class="ms-lbl">Avg. Change</div></div>
  `;
  summaryEl.classList.remove('hidden');
}

function searchMarket() {
  marketSearchQuery = document.getElementById('marketSearch')?.value.trim().toLowerCase() || '';
  applyMarketFilter();
}

function filterMarket() {
  marketFilterValue = document.getElementById('marketFilter')?.value || 'all';
  applyMarketFilter();
}

function applyMarketFilter() {
  const filtered = marketData.filter(item => {
    const matchesCommodity = marketFilterValue === 'all' || item.commodity === marketFilterValue;
    const matchesSearch = marketSearchQuery === '' || item.crop.toLowerCase().includes(marketSearchQuery) || item.mandi.toLowerCase().includes(marketSearchQuery);
    return matchesCommodity && matchesSearch;
  });
  renderMarketResults(filtered);
}

function renderMarketResults(items) {
  const target = document.getElementById('market-results');
  target.innerHTML = '';

  if (!items.length) {
    target.innerHTML = `<div class="results-placeholder"><div class="placeholder-icon">📉</div><div class="placeholder-text">No market entries match the filter or search criteria.</div></div>`;
    return;
  }

  const wrapper = document.createElement('div');
  wrapper.className = 'market-table-wrap';
  wrapper.innerHTML = `
    <table class="market-table">
      <thead>
        <tr>
          <th>Crop</th>
          <th>Commodity</th>
          <th>Mandi</th>
          <th>Price</th>
          <th>Change</th>
          <th>Demand</th>
        </tr>
      </thead>
      <tbody>
        ${items.map(item => `
          <tr>
            <td>${item.crop}</td>
            <td>${item.commodity}</td>
            <td>${item.mandi}, ${item.state}</td>
            <td class="price-cell">₹${item.live_price} / ${item.unit}</td>
            <td class="${item.trend === 'up' ? 'trend-up' : 'trend-dn'}">${item.change >= 0 ? '+' : ''}${item.change_pct}%</td>
            <td>${item.demand}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
  target.appendChild(wrapper);
}

function handleFileSelect(event) {
  const file = event.target.files?.[0];
  if (file) {
    processUploadFile(file);
  }
}

function handleDrop(event) {
  event.preventDefault();
  event.currentTarget.classList.remove('drag-over');
  const file = event.dataTransfer.files?.[0];
  if (file) {
    processUploadFile(file);
  }
}

function processUploadFile(file) {
  const supportedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
  if (!supportedTypes.includes(file.type) || file.size > 10 * 1024 * 1024) {
    showToast('Only JPG, JPEG, or PNG files under 10 MB are accepted.');
    return;
  }

  const preview = document.getElementById('upload-preview');
  const img = document.getElementById('preview-img');
  const name = document.getElementById('preview-name');
  const fileInput = document.getElementById('cropFile');
  fileInput.files = createFileList(file);
  img.src = URL.createObjectURL(file);
  name.textContent = file.name;
  preview.classList.remove('hidden');
  document.getElementById('analyze-btn').disabled = false;
}

function createFileList(file) {
  const dataTransfer = new DataTransfer();
  dataTransfer.items.add(file);
  return dataTransfer.files;
}

function clearFile() {
  const preview = document.getElementById('upload-preview');
  const img = document.getElementById('preview-img');
  const name = document.getElementById('preview-name');
  const fileInput = document.getElementById('cropFile');

  fileInput.value = '';
  img.src = '';
  name.textContent = '';
  preview.classList.add('hidden');
  document.getElementById('analyze-btn').disabled = true;
}

async function analyzeDisease() {
  const fileInput = document.getElementById('cropFile');
  const file = fileInput.files?.[0];
  if (!file) {
    showToast('Please upload an image before analyzing.');
    return;
  }

  const button = document.getElementById('analyze-btn');
  startButtonLoading(button);
  document.getElementById('disease-results').innerHTML = '<div class="loading-spinner">Analyzing the image…</div>';

  const formData = new FormData();
  formData.append('cropImage', file);

  try {
    const response = await fetch(`${apiBase}/disease/analyze`, { method: 'POST', body: formData });
    const data = await response.json();

    if (!data.success || !data.analysis) {
      renderError('disease-results', data.error || 'Unable to analyze image.');
      return;
    }

    renderDiseaseResult(data.analysis);
  } catch (err) {
    renderError('disease-results', 'Analysis service unavailable. Please try again later.');
  } finally {
    stopButtonLoading(button);
  }
}

function renderDiseaseResult(analysis) {
  const container = document.getElementById('disease-results');
  container.innerHTML = '';

  if (analysis.is_plant === false) {
    container.innerHTML = `<div class="error-box">The uploaded image does not appear to be a plant or crop. ${analysis.message || ''}</div>`;
    return;
  }

  const riskClass = {
    None: 'risk-none',
    Low: 'risk-low',
    Medium: 'risk-medium',
    High: 'risk-high',
    Critical: 'risk-critical'
  }[analysis.risk_level] || 'risk-medium';

  const diseaseCard = document.createElement('article');
  diseaseCard.className = 'disease-result-card';
  diseaseCard.innerHTML = `
    <div class="dr-header">
      <div class="dr-plant">
        <div>
          <div class="dr-plant-name">${analysis.plant_type || 'Unknown Plant'}</div>
          <div class="dr-disease">${analysis.disease_name || 'Diagnosis unavailable'}</div>
        </div>
        <span class="risk-badge ${riskClass}">${analysis.risk_level || 'Unknown'} (${analysis.risk_score || 0})</span>
      </div>
      <div class="risk-bar-wrap"><div class="risk-bar" style="width:${analysis.risk_score || 0}%"></div></div>
    </div>
    <div class="dr-body">
      <div>
        <div class="dr-section-title">Symptoms Observed</div>
        <div class="dr-tags">${(analysis.symptoms_observed || []).map(symptom => `<span class="dr-tag">${symptom}</span>`).join('')}</div>
      </div>
      <div>
        <div class="dr-section-title">Likely Causes</div>
        <div class="dr-tags">${(analysis.causes || []).map(cause => `<span class="dr-tag">${cause}</span>`).join('')}</div>
      </div>
      <div>
        <div class="dr-section-title">Affected Parts</div>
        <div class="dr-tags">${(analysis.affected_parts || []).map(part => `<span class="dr-tag">${part}</span>`).join('')}</div>
      </div>
      <div class="urgent-box">
        <div class="urgent-label">Urgent Action</div>
        <div class="urgent-text">${analysis.urgent_action || 'Follow expert guidance immediately.'}</div>
      </div>
      <div class="impact-row">
        <div class="impact-box"><div class="impact-val">${analysis.yield_impact || 'Unknown'}</div><div class="impact-lbl">Yield Impact</div></div>
        <div class="impact-box"><div class="impact-val">${analysis.recovery_timeline || 'Unknown'}</div><div class="impact-lbl">Recovery Timeline</div></div>
        <div class="impact-box"><div class="impact-val">${analysis.confidence || 0}%</div><div class="impact-lbl">Confidence</div></div>
      </div>
      <div>
        <div class="dr-section-title">Organic Treatments</div>
        <div class="treatment-list">${(analysis.organic_treatments || []).map(step => `
          <div class="treatment-item">
            <div class="treatment-step">${step.step}</div>
            <div class="treatment-text"><strong>${step.action}</strong><br/>${step.product || ''}${step.frequency ? ` — ${step.frequency}` : ''}</div>
          </div>
        `).join('')}</div>
      </div>
      <div>
        <div class="dr-section-title">Chemical Treatments</div>
        <div class="treatment-list">${(analysis.chemical_treatments || []).map(step => `
          <div class="treatment-item">
            <div class="treatment-step chem">${step.step}</div>
            <div class="treatment-text"><strong>${step.action}</strong><br/>${step.product || ''}${step.dosage ? ` — ${step.dosage}` : ''}${step.frequency ? `, ${step.frequency}` : ''}</div>
          </div>
        `).join('')}</div>
      </div>
      <div>
        <div class="dr-section-title">Preventive Tips</div>
        <ul class="advisory-list">
          ${(analysis.preventive_tips || []).map(tip => `<li>${tip}</li>`).join('')}
        </ul>
      </div>
    </div>
  `;

  container.appendChild(diseaseCard);
}
